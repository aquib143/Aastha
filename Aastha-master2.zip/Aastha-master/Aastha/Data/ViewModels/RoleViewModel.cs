namespace Aastha.Data.ViewModels
{
    public class RoleViewModel
    {
        public string Id { get; set; }
        public string Name{ get; set; }
        public bool Select { get; set; }
    }
}